<html>
<head>

<style>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</style>


</head>


<?php

require 'includes/init.php';

if(isset($_SESSION['user_id']) ){
    $user_data = $user_obj->find_user_by_id($_SESSION['user_id']);
    if($user_data ===  false){
        header('Location: logout.php');
        exit;
    }
}
else{
    header('Location: logout.php');
    exit;
}


// TOTLA FRIENDS
$get_frnd_num = $frnd_obj->get_all_friends($_SESSION['user_id'], false);
// GET MY($_SESSION['user_id']) ALL FRIENDS
$get_all_friends = $frnd_obj->get_all_friends($_SESSION['user_id'], true);


$output = '
<table class="table table-hover">
	<tr>
		<th width="70%">Username</td>
		<th width="20%">User ID Number</td>
		<th width="10%">Action</td>
	</tr>';

if($get_frnd_num > 0){
    foreach($get_all_friends as $row){
        $output .= '<tr>
			<td> '.$row->username.'</td>
			
            <td>'.$row->user_id.'</td>
			
			<td><button type="button" class="btn btn-info btn-xs start_chat" data-touserid= '.$row->user_id.'  
			data-tousername='.$row->username.'>Start Chat</button></td>	
			
			</tr>';
    }
}

	
$output .= '</table>';

echo $output;

?>




</html>
<?php 
    define('TITLE',"Home | Complete Registertion From");
    include 'includes/header.php';
	include 'includes/icon.html';
	header('X-Content-Type-Options: nosniff');
?>
<div id="philosophy">

<center> <a class="navbar-brand" href="index.php"><img src="pic/tristanwong's logo.png"></a> </center>

    <hr>

	
	<div class="card-body bg-info">
	
      
	<center>&#9886;ATTENTION PLEASE:&#9887;</center> <br>
	Once you close our web page, you should log out first because of security.<br>
	Thank you for your cooperation!
    <br><br>
	</div>
	
    
    
    <br><br><br>
    
</div>

<?php 
    include 'includes/footer.php';
?>

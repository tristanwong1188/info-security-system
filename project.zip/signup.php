<html>
<head>
<style>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</style>
</head>

<body>

<?php
    define('TITLE',"Signup");
    include 'includes/header.php';
	include 'includes/icon.html';
	header_remove("X-Powered-By");
	header('X-Content-Type-Options: nosniff');
	header('X-Frame-Options: DENY');
    
    if(isset($_SESSION['userId']))
    {
        header("Location: index.php");
        exit();
    }
?>

<div id="contact">
    <center> <a class="navbar-brand" href="index.php"><img src="pic/tristanwong's logo.png"></a> </center>
    <hr>
    <h1>Signup</h1>
    <?php
    
        $userName = '';
        $email = '';
    
        if(isset($_GET['error']))
        {
            if($_GET['error'] == 'emptyfields')
            {
                echo '<div class="alert alert-warning"><p class="closed"><strong>Warning!</strong>
				Fill In All The Fields</p></div>';
                $userName = $_GET['uid'];
                $email = $_GET['mail'];
            }
            else if ($_GET['error'] == 'invalidmailuid')
            {
                echo '<div class="alert alert-warning"><strong>Warning!</strong>
				<p class="closed">Please enter a valid email and user name</p></div>';
            }
            else if ($_GET['error'] == 'invalidmail')
            {
                echo '<div class="alert alert-warning"><strong>Warning!</strong>
				<p class="closed">Please enter a valid email</p></div>';
            }
            else if ($_GET['error'] == 'invaliduid')
            {
                echo '<div class="alert alert-warning"><strong>Warning!</strong>
				<p class="closed">Please enter a valid user name</p></div>';
            }
            else if ($_GET['error'] == 'passwordcheck')
            {
                echo '<div class="alert alert-warning"><strong>Warning!</strong>
				<p class="closed">*Passwords donot match</p></div>';
            }
            else if ($_GET['error'] == 'usertaken')
            {
                echo '<div class="alert alert-warning"><strong>Warning!</strong>
				<p class="closed">*This User name is already taken</p></div>';
            }
            else if ($_GET['error'] == 'invalidimagetype')
            {
                echo '<div class="alert alert-warning"><strong>Warning!</strong>
				<p class="closed">*Invalid image type. Profile image must be a .jpg or .png file</p></div>';
            }
            else if ($_GET['error'] == 'imguploaderror')
            {
                echo '<div class="alert alert-warning"><strong>Warning!</strong>
				<p class="closed">*Image upload error</p></div>';
            }
            else if ($_GET['error'] == 'imgsizeexceeded')
            {
                echo '<div class="alert alert-warning"><strong>Warning!</strong>
				<p class="closed">*Image too large</p></div>';
            }
            else if ($_GET['error'] == 'sqlerror')
            {
                echo '<div class="alert alert-danger"><strong>Danger!</strong>
				<p class="closed">Website Error: Contact admin to have the issue fixed</p></div>';
            }
        }
        else if (isset($_GET['signup']) == 'success')
        {
            echo '  <div class="alert alert-success"><strong>Success!</strong>
			<p class="open">Signup Successful. Please login with your Login ID from the Login menu on the right.</p></div>';
        }
    ?>
    <form action="includes/signup.inc.php" method='post' id="contact-form" enctype="multipart/form-data" class="card card-body">
	<?php
			$csrf = isset($_POST['csrf']) ? $_POST['csrf'] : '';
	
			$token = md5(uniqid(rand(), true));
			$_session['csrf'] = $token;
	
	
	
			if($_session['csrf'] === $csrf)
			{
				echo "welcome!";
				unset ($_session['csrf']);
			}
	
            
	?> 

        <input type="text" id="name" name="uid" placeholder="LOGIN ID" value=<?php echo $userName; ?>>
        <input type="email" id="email" name="mail" placeholder="email" value=<?php echo $email; ?>>
        <input type="password" id="pwd" name="pwd" placeholder="password">
        <input type="password" id="pwd-repeat" name="pwd-repeat" placeholder="repeat password">
		<input type="hidden" id="csrf" name="csrf" placeholder="CSRF" value = <?php$token?> 
        
        <h5>Profile Picture</h5>
        <div class="upload-btn-wrapper">
            <button class="btn btn-primary">Upload a file</button>
            <input type="file" name='dp'>
        </div>
        <!-- <img id="userDp" src="" >-->
        
        <h5>Gender</h5>
        <label class="container" for="gender-m">&#160;&#160;&#160;&#160;Male
          <input type="radio" checked="checked" name="gender" value="m" id="gender-m">
          <span class="checkmark"></span>
        </label>
        <label class="container" for="gender-f">&#160;&#160;&#160;&#160;Female
          <input type="radio" name="gender" value="f" id="gender-f">
          <span class="checkmark"></span>
        </label>

        <h5>Optional</h5>
        <input type="text" id="f-name" name="f-name" placeholder="First Name" >
        <input type="text" id="l-name" name="l-name" placeholder="Last Name" >
        <input type="text" id="headline" name="headline" placeholder="Your Profile Headline">
        <textarea id="bio" name="bio" placeholder="What you want to tell people about yourself"></textarea>
        
        <input type="submit" class="button next" name="signup-submit" value="signup">
        
    </form>
    <hr>
</div>

<?php include 'includes/footer.php'; ?> 

</body>

</html>
<html>
<head>
<link href="css/bootstrap.css" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>	

</head>



<body>

      
<div class="jumbotron text-center">
  <p>Powered By Krazytech</p> 
  <p>Modified and Developed By WONG PAK HO</p> 
  <p>All rights reserved &#169; 2021</p> 
</div>	

</body>

</html>

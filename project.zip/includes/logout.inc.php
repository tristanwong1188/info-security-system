<?php
    session_start();
	
	// set the expiration date to one hour ago
	$cookie_name = "user";
	$cookie_value = $_SESSION['username'];
	
	setcookie($cookie_name, $_SESSION['username'], time() - 3600);
	
	echo "Cookie 'user' is deleted.";

    session_unset();
    session_destroy();
    header("Location: ../index.php");

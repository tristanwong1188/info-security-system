<?php

    session_start();
    require 'dbh.inc.php';
	
	//framework name:
    $companyName = "PHP Login/Registration System";
	
    header_remove("X-Powered-By");
	header('X-Content-Type-Options: nosniff');
	
    function strip_bad_chars( $input ){
        $output = preg_replace( "/[^a-zA-Z0-9_-]/", "", $input);
        return $output;
    }
?>  

<!DOCTYPE html>

<html>
    <head>
        <title><?php echo TITLE; ?></title>
        <link href="includes/styles.css" rel="stylesheet"> 
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

		
    </head>
    <body id="final-example">
        
    <!-------     LOGIN / LOGOUT FORM               --------->
    
        
    <div id="login">
        
        <?php 
            
            if(isset($_SESSION['user_id']))
            {
                echo'<div style="text-align: center;" class = "card card-body">
                        <img id="userDp" src=./uploads/'.$_SESSION['userImg'].'>
                        <h3>' . strtoupper($_SESSION['username']) . '</h3>
                        <a href="profile.php" class="button login">Profile</a>  
						<a href="edit-profile.php" class="button login">Edit Profile</a>
						<a href="friend_profile.php" class="button login">Friend List</a>
                        <a href="logout.php" class="button login">Logout</a>
                    </div>';
					
			
			
			// Using the SetCookie built-in PHP function.
			setcookie(
				$cookie_name = "user",    // Name of the cookie.
				$cookie_value = $_SESSION['username'],   // Value of the cookie.
				$expire = time() + 3600,  // Time the cookie expires in Unix timestamp.
				$path = "../cookies",    // Path on the server in which the cookie will be.
				$domain = "twchat.ga",  // The domain that the cookie is available to.
				$secure = true,  // Transmitted only over a secure HTTPS connection.
				$httponly = true // Make accessible only through the HTTP protocol.
			);

            }
            else
            {
                if(isset($POST['error']))
                {
                    if($POST['error'] == 'emptyfields')
                    {
                        echo '<div class="alert alert-warning"><p class="closed"><strong>Warning!</strong>
						please fill in all the fields</p></div>';
                    }
                    else if($POST['error'] == 'nouser')
                    {
                        echo '<div class="alert alert-warning"><p class="closed"><strong>Warning!</strong>
						username does not exist</p></div>';
                    }
                    else if ($POST['error'] == 'wrongpwd')
                    {
                        echo '<div class="alert alert-warning"><p class="closed"><strong>Warning!</strong>
						wrong password</p></div>';
                    }
                    else if ($POST['error'] == 'sqlerror')
                    {
                        echo '<div class="alert alert-danger"><p class="closed"><strong>Danger!</strong>
						Website Error. Please contact admin to have it fixed</p></div>';
                    }
                }
			$csrf = isset($_POST['csrf']) ? $_POST['csrf'] : '';
	
			$token = md5(uniqid(rand(), true));
			$_session['csrf'] = $token;
			
                echo '<div class="card" style="width = 10% height = 30%"><div class="card-body"><form method="post" action="includes/login.inc.php" id="login-form">
                    <input type="text" id="name" name="mailuid" placeholder="Username...">
                    <input type="password" id="password" name="pwd" placeholder="Password...">
					<input type="hidden" id="csrf" name="csrf" placeholder="CSRF" value = $token >
					<div class="btn-group btn-group-lg">
                    <input type="submit" class="button next login" name="login-submit" value="Login">
					
                </form>
                <a href="signup.php" class="button previous">Signup</a></div></div></div></div> ';  

			if($_session['csrf'] === $csrf)
			{
				echo "welcome!";
				unset ($_session['csrf']);
			}
            
			}
			
			
			?> 
			
			
        

    </div>
    
    <!-------     LOGIN / LOGOUT FORM END           --------->
        <div class="wrapper">
            <div class="content">
			
			
</body>

</html>
<html>
<head>
<style>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</style>
</head>

<body>

<?php
    define('TITLE', "Edit Profile");
    include 'includes/header.php';
	include 'includes/icon.html';
    
    if (!isset($_SESSION['user_id']))
    {
        header("Location: index.php");
        exit();
    }    
?>

<div style="text-align: center">
    <img id="userDp" src=<?php echo "./uploads/".$_SESSION['userImg']; ?> >
 
    <h1><?php echo strtoupper($_SESSION['username']); ?></h1>  
</div>

<?php
        $userName = '';
        $email = ''; 
    
        if(isset($_GET['error']))
        {
            if($_GET['error'] == 'emptyemail')
            {
                echo '<div class="alert alert-warning"><p class="closed"><strong>Warning!</strong>
				Profile email cannot be empty</p></div>';
                $email = $_GET['mail'];
            }
            else if ($_GET['error'] == 'invalidmail')
            {
                echo '<div class="alert alert-warning"><p class="closed"><strong>Warning!</strong>
				Please enter a valid email</p></div>';
            }
            else if ($_GET['error'] == 'emptyoldpwd')
            {
                echo '<div class="alert alert-warning"><p class="closed"><strong>Warning!</strong>
				You must enter the current password to change it</p></div>';
            }
            else if ($_GET['error'] == 'emptynewpwd')
            {
                echo '<div class="alert alert-warning"><p class="closed"><strong>Warning!</strong>
				Please enter the new password</p></div>';
            }
            else if ($_GET['error'] == 'emptyreppwd')
            {
                echo '<div class="alert alert-warning"><p class="closed"><strong>Warning!</strong>
				Please confirm new password</p></div>';
            }
            else if ($_GET['error'] == 'wrongpwd')
            {
                echo '<div class="alert alert-warning"><p class="closed"><strong>Warning!</strong>
				Current password is wrong</p></div>';
            }
            else if ($_GET['error'] == 'samepwd')
            {
                echo '<div class="alert alert-danger"><p class="closed"><strong>Danger!</strong>
				New password cannot be same as old password</p></div>';
            }
            else if ($_GET['error'] == 'passwordcheck')
            {
                echo '<div class="alert alert-danger"><p class="closed"><strong>Danger!</strong>
				Confirmation password is not the same as the new password</p></div>';
            }
        }
        else if (isset($_GET['edit']) == 'success')
        {
            echo '<div class="alert alert-success"><strong>Success!</strong>
			<p class="open">Profile Updated Successfully</p></div>';
        }
?>

<form action="includes/profileUpdate.inc.php" method='post' id="contact-form" enctype="multipart/form-data" class="card card-body">

        <h5>Personal Information</h5>
        
        <label for="email">Email</label>
        <input type="email" id="email" name="email" placeholder="email" 
               value=<?php echo $_SESSION['emailUsers']; ?>><br>
                
        <label>Nick Name</label>
        <input type="text" id="f-name" name="f-name" placeholder="First Name" 
               value=<?php echo $_SESSION['f_name']; ?>>
        <input type="text" id="l-name" name="l-name" placeholder="Last Name" 
               value=<?php echo $_SESSION['l_name']; ?>>
        
        <label class="container" for="gender-m">&#160;&#160;&#160;&#160;Male
          <input type="radio" name="gender" value="m" id="gender-m"
                 <?php if ($_SESSION['gender'] == 'm'){ ?> 
                 checked="checked"
                 <?php } ?>>
          <span class="checkmark"></span>
        </label>
        <label class="container" for="gender-f">&#160;&#160;&#160;&#160;Female
          <input type="radio" name="gender" value="f" id="gender-f"
                 <?php if ($_SESSION['gender'] == 'f'){ ?> 
                 checked="checked"
                 <?php } ?>>
          <span class="checkmark"></span>
        </label>
       
        <label for="headline">Profile Headline</label>
        <input type="text" id="headline" name="headline" placeholder="Your Profile Headline"
               value='<?php echo $_SESSION['headline']; ?>'><br>
        
        <label for="bio">Profile Bio</label>
        <textarea id="bio" name="bio" maxlength="5000"
            placeholder="What you want to tell people about yourself" 
            ><?php echo $_SESSION['bio']; ?></textarea>
        
        <h5>Change Password</h5>
        <input type="password" id="old-pwd" name="old-pwd" placeholder="current password"><br>
        <input type="password" id="pwd" name="pwd" placeholder="new password">
        <input type="password" id="pwd-repeat" name="pwd-repeat" placeholder="repeat new password">
        
        <h5>Profile Picture</h5>
        <div class="upload-btn-wrapper">
            <button class="btn btn-primary">Upload a file</button>
            <input type="file" name='dp' value=<?php echo $_SESSION['userImg']; ?>>
        </div>
        
        <input type="submit" class="button next" name="update-profile" value="Update Profile">
        
    </form>
<hr>

<?php include 'includes/footer.php'; ?> 

</body>

</html>
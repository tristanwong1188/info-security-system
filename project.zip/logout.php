<?php

//logout.php

session_start();
header_remove("X-Powered-By");

// set the expiration date to one hour ago
$cookie_name = "user";
$cookie_value = $_SESSION['username'];
setcookie($cookie_name, $_SESSION['username'], time() - 3600);

echo "Cookie 'user' is deleted.";
session_destroy();

header('location:index.php');

?>
<?php 
    define('TITLE',"My Profile");
    include 'includes/header.php';
	include 'includes/icon.html';
    
    if(!isset($_SESSION['user_id']))
    {
        header("Location: index.php");
        exit();
    }
?>


<div style="text-align: center">
    <img id="userDp" src=<?php echo "./uploads/".$_SESSION['userImg']; ?> >
 
    <h1><?php echo strtoupper($_SESSION['username']); ?></h1>
    <hr>
</div>

<div class = "card card-body bg-primary"><p>
<h3>Name: <?php echo strtoupper($_SESSION['f_name']) . " " . strtoupper($_SESSION['l_name']); ?></h3>                

<?php 
    if ($_SESSION['gender'] == 'm')
    {
        echo 'Gender: Male';
    }
    else if ($_SESSION['gender'] == 'f')
    {
        echo 'Gender: Female';
    }
?>
</p></div><br>


<div class = "card card-body bg-secondary text-white">
<h6><center>Headline: </center><br><?php echo $_SESSION['headline']; ?></h6></div><br>


<div class = "card card-body bg-light"><p><center>Personal Biography: </center><?php echo $_SESSION['bio'];?></p> </div>


<br><br><br><br>

                
                
<?php include 'includes/footer.php'; ?> 


                

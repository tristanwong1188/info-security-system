<?php

$mysql_host = "localhost";
$mysql_database = "chat";
$mysql_user = "root";
$mysql_password = "ma2002s0436kd";

# MySQL with PDO_MYSQL  
$db = new PDO("mysql:host=$mysql_host;dbname=$mysql_database", $mysql_user, $mysql_password);

$query = file_get_contents("DBS.sql");

$stmt = $db->prepare($query);

if ($stmt->execute())
     echo "Success";
else 
     echo "Fail"


?>